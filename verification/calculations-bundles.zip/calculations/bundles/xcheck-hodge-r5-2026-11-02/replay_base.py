"""Replay the independent <=105 base without a pre-existing executable.

Usage: python3 -I replay_base.py NEW_OUTPUT_DIRECTORY
Uses one CPU, a C compiler and Python's standard library. Keeps every raw
enumerator row; an existing output directory is never overwritten.
The unchanged enum6.c and classify.py are the xcheck-r5 reviewers' work.
"""

import importlib.util
import json
import os
import platform
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path


def replay(output):
    source = Path(__file__).resolve().parent
    independent = source.parent / "xcheck-hodge-thm720-2026-10-29/hs_enum3.c"
    spec = importlib.util.spec_from_file_location("xcheck_classify", source / "classify.py")
    predicates = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(predicates)
    output.mkdir(parents=True, exist_ok=False)
    compiler = shlex.split(os.environ.get("CC", "cc"))
    flags = shlex.split(os.environ.get("CFLAGS", "-O2"))
    with (output / "compile.txt").open("w") as log:
        for src, executable in [(source / "enum6.c", "enum6"), (independent, "hs_enum3")]:
            command = [*compiler, *flags, str(src), "-o", str(output / executable)]
            log.write(shlex.join(command) + "\n")
            log.flush()
            subprocess.run(command, check=True, stdout=log, stderr=subprocess.STDOUT)
    (output / "environment.txt").write_text(
        f"Python: {sys.version}\nPlatform: {platform.platform()}\n"
        + subprocess.run([*compiler, "--version"], check=True,
                         capture_output=True, text=True).stdout
    )
    totals = dict(degrees=0, pairfree=0, residual=0, primitive=0)
    start = time.monotonic()
    with (output / "classification.jsonl").open("w") as report:
        for m in range(3, 106, 2):
            raw = output / f"m{m}.txt"
            with raw.open("w") as out, (output / f"m{m}.stderr.txt").open("w") as err:
                subprocess.run([str(output / "enum6"), str(m)], check=True,
                               stdout=out, stderr=err)
            units = predicates.units(m)
            orbits = set()
            rows = 0
            with raw.open() as data:
                for line in data:
                    a = tuple(map(int, line.split()))
                    assert len(a) == 6 and all(0 < x < m for x in a), (m, a)
                    assert predicates.hodge(a, m, units), (m, a)
                    rows += 1
                    if not predicates.has_pair(a, m):
                        orbits.add(predicates.canon(a, m, units))
            residual = set()
            standard = decomposable = 0
            categories = dict(std5=set(), dec=set(), residual=residual)
            for a in sorted(orbits):
                if predicates.std5(a, m):
                    standard += 1
                    categories["std5"].add(a)
                elif predicates.dec(a, m, units):
                    decomposable += 1
                    categories["dec"].add(a)
                else:
                    residual.add(a)
            # Run the independent three-plus-three implementation afresh;
            # archived answers are not an input to either enumerator.
            independent_raw = output / f"m{m}.three-plus-three.txt"
            with independent_raw.open("w") as out, (output / f"m{m}.three-plus-three.stderr.txt").open("w") as err:
                subprocess.run([str(output / "hs_enum3"), str(m), "verbose"], check=True,
                               stdout=out, stderr=err)
            original = independent_raw.read_text().splitlines()
            summary, = [line for line in original if line.startswith("SUMMARY ")]
            counts = {k: int(v) for k, v in re.findall(r"(\w+)=(\d+)", summary)}
            assert counts["m"] == m, (m, counts)
            expected = {tuple(map(int, line.split()[-6:])) for line in original
                        if line.startswith("RESIDUAL ")}
            for category, tuples in categories.items():
                other = {tuple(map(int, line.split()[-6:])) for line in original
                         if line.startswith(f"ORBIT m={m} category={category} ")}
                assert tuples == other, (m, category, tuples, other)
            assert len(orbits) == counts["orbit_classes"], (m, "pairfree")
            assert standard == counts["std5"], (m, "standard")
            assert decomposable == counts["dec"], (m, "decomposable")
            assert len(residual) == counts["residual_orbits"], (m, "residual")
            assert residual == expected == predicates.predicted(m), (m, residual, expected)
            primitive = sum(predicates.content(a, m) == 1 for a in residual)
            row = dict(degree=m, raw_rows=rows, pairfree=len(orbits), std5=standard,
                       dec=decomposable, residual=sorted(residual), primitive=primitive,
                       orbits={k: sorted(v) for k, v in categories.items()},
                       status="PASS")
            report.write(json.dumps(row) + "\n")
            report.flush()
            for key, value in dict(degrees=1, pairfree=len(orbits),
                                   residual=len(residual), primitive=primitive).items():
                totals[key] += value
            print(json.dumps(row), flush=True)
        assert totals == dict(degrees=52, pairfree=57, residual=7, primitive=6), totals
        final = dict(**totals, elapsed_seconds=time.monotonic() - start, status="PASS")
        report.write(json.dumps(final) + "\n")
        print(json.dumps(final), flush=True)


if __name__ == "__main__":
    replay(Path(sys.argv[1]).resolve())
