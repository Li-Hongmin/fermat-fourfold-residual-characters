// Independent enumerator (r4 xcheck): all Hodge 6-multisets of nonzero residues mod odd m,
// first coordinate a proper divisor g|m (unit-orbit representative), other five sorted.
// Hodge: sum_i [t a_i]_m = 3m for every unit t. Prints each hit; dedup/classify in Python.
#include <stdio.h>
#include <stdlib.h>
static int gcd(int a,int b){while(b){int t=a%b;a=b;b=t;}return a;}
int main(int argc,char**argv){
  int m=atoi(argv[1]); int nu=0; int *U=malloc(sizeof(int)*m);
  for(int t=1;t<m;t++) if(gcd(t,m)==1) U[nu++]=t;
  for(int g=1;g<m;g++){ if(m%g) continue;
    for(int a1=1;a1<m;a1++) for(int a2=a1;a2<m;a2++) for(int a3=a2;a3<m;a3++) for(int a4=a3;a4<m;a4++){
      int a5=3*m-g-a1-a2-a3-a4; if(a5<a4||a5>=m) continue;
      int a[6]={g,a1,a2,a3,a4,a5}; int ok=1;
      for(int k=0;k<nu&&ok;k++){ int t=U[k]; long s=0; for(int i=0;i<6;i++) s+=(long)t*a[i]%m; if(s!=3L*m) ok=0; }
      if(ok) printf("%d %d %d %d %d %d\n",a[0],a[1],a[2],a[3],a[4],a[5]);
    }
  }
  return 0;
}
