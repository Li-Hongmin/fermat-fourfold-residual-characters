#!/usr/bin/env python3 -I
"""r4 xcheck: classify Hodge sextuples (from enum6) into Dec / Std5 / residual; compare with six seeds."""
import sys, subprocess, itertools
from math import gcd
from functools import reduce

SEEDS = [(33,(1,4,16,22,25,31)),(39,(1,7,16,22,34,37)),(39,(1,14,16,22,29,35)),
         (45,(1,19,20,28,30,37)),(105,(1,22,43,64,90,95)),(105,(3,24,50,66,85,87))]

def units(m): return [t for t in range(1,m) if gcd(t,m)==1]
def hodge(a,m,U):
    n=len(a)
    return all(sum(t*x%m for x in a)==(n//2)*m for t in U)
def canon(a,m,U):
    return min(tuple(sorted(t*x%m for x in a)) for t in U)
def has_pair(a,m):
    s=set(a)
    return any((-x)%m in s for x in a)
def dec(a,m,U):
    if has_pair(a,m): return True
    for idx in itertools.combinations(range(6),3):
        if idx[0]!=0: continue
        B=[a[i] for i in idx]; C=[a[i] for i in range(6) if i not in idx]
        s=sum(B)%m
        if s==0: continue
        if hodge(B+[(-s)%m],m,U) and hodge([s]+C,m,U): return True
    return False
def std5(a,m):
    if m%5: return False
    d=m//5; A=sorted(a)
    for i in range(m):
        if d//gcd(i,d)<=2 and not (i%d==0 and False):
            # admissibility d/gcd(i,d)>2 ; gcd(0,d)=d gives 1
            continue
        if sorted([(i+j*d)%m for j in range(5)]+[(-5*i)%m])==A: return True
    return False
def content(a,m): return reduce(gcd,a,m)
def run(m):
    out=subprocess.run(["/tmp/r4x/enum6",str(m)],capture_output=True,text=True).stdout.split("\n")
    U=units(m); orbs=set()
    for line in out:
        if line.strip():
            a=tuple(int(x) for x in line.split()); orbs.add(canon(a,m,U))
    res=[]; npf=0
    for o in orbs:
        if has_pair(o,m): continue
        npf+=1
        if dec(o,m,U) or std5(o,m): continue
        res.append(o)
    return U,len(orbs),npf,res
def predicted(m):
    U=units(m); P=set()
    for d,a in SEEDS:
        if m%d==0:
            k=m//d; P.add(canon([k*x%m for x in a],m,U))
    return P
if __name__=="__main__":
    ms=[int(x) for x in sys.argv[1:]] or list(range(3,106,2))
    allok=True; tot=[0,0,0,0]
    for m in ms:
        U,no,npf,res=run(m)
        pred=predicted(m); got=set(res); ok=(pred==got)
        prim=[r for r in res if content(r,m)==1]
        tot[0]+=1; tot[1]+=npf; tot[2]+=len(res); tot[3]+=len(prim)
        if not ok or m in (33,39,45,99,105) or len(res)>0:
            print(m,"orbits",no,"pairfree",npf,"resid",len(res),"primitive",len(prim),"MATCH" if ok else "MISMATCH", "extra",sorted(got-pred),"missing",sorted(pred-got))
        allok&=ok
    print("degrees",tot[0],"pairfree",tot[1],"residual",tot[2],"primitive",tot[3],"ALL_MATCH" if allok else "FAIL")
