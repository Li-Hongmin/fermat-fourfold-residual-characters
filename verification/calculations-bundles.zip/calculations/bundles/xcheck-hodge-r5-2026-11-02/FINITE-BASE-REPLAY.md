# Complete finite-base replay

From the repository root, run:

```sh
python3 -I calculations/bundles/xcheck-hodge-r5-2026-11-02/replay_base.py \
    scratch/finite-base-replay
```

This uses one CPU and the standard library, builds `enum6.c` in the new
output directory, retains every raw row, and checks all 52 odd degrees
from 3 through 105. It reuses the original reviewers' `classify.py`
predicates without calling that file's legacy `/tmp/r4x/enum6` entry point.
Compiler/enumerator failures and disagreements exit nonzero. The R8 driver
also builds and runs `../xcheck-hodge-thm720-2026-10-29/hs_enum3.c` afresh.
It compares the complete canonical orbit sets in each category, not only
the counts and residuals. The C three-plus-three implementation has just
an added optional `verbose` output line per orbit; its enumerator and
classification predicates are unchanged. Archived answers are not inputs
to either enumerator. The candidate seed list is used only after enumeration.
The output directory must not already exist. `CC` and `CFLAGS` can override
the default `cc -O2`; on the development Mac the required override was
`CFLAGS='-O2 -isysroot /Library/Developer/CommandLineTools/SDKs/MacOSX26.5.sdk'`.

`results/r8-20261102/` retains the complete fresh dual replay (its per-degree raw outputs `m*.txt` are packed losslessly in `raw-rows.tar.gz` in that directory), including
69,548 direct candidate rows, every classified pair-free orbit from the
three-plus-three implementation, 52 per-degree comparisons and the environment.
The disjoint classification totals are 15 exact-standard, 35 other surface
contractions and seven residuals. Both compiled binaries are rebuilt on replay
and are not part of the retained data. Supplement S1 accompanying the paper
includes the sources, this entry point and these data under the same relative
paths, and works without a repository checkout.
