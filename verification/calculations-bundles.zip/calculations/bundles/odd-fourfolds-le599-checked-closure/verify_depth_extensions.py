"""Finite checks of the new three-slice shapes and the 5-primary endpoint.

Run on the allocated node; one CPU and no third-party dependencies.
These are direct formula checks, not proofs for unbounded conductors.
"""
from itertools import product
import json
import sys
from pathlib import Path

# Allow `python3 -I` (isolated mode omits the script directory from sys.path).
sys.path.insert(0, str(Path(__file__).resolve().parent))
from verify_two_prime_depth import age_check, potentials


def shapes(columns):
    found = {}
    for a, b in product(range(-6, 7), repeat=2):
        options = [(x, x+a, x+b) for x in range(-6, 7)
                   if 0 < abs(x)+abs(x+a)+abs(x+b) <= 6
                   and not (min(x, x+a, x+b) > 0 or max(x, x+a, x+b) < 0)]
        # A nonzero column has mass at least one; the short recursion is
        # equivalent to enumerating all integer additive split matrices.
        if a == b == 0:
            continue  # every nonzero constant column has a same-sign line

        def visit(prefix, budget):
            if len(prefix) == columns:
                rows = tuple(tuple(col[i] for col in prefix) for i in range(3))
                nonzero = [row for row in rows if any(row)]
                if len(nonzero) == 1:
                    assert len(set(nonzero[0])) == 1 and abs(nonzero[0][0]) == 1
                    kind = "single_line"
                else:
                    assert len(nonzero) == 3 and len(set(rows)) == 2
                    repeated = next(row for row in rows if rows.count(row) == 2)
                    other = next(row for row in rows if row != repeated)
                    delta = {y-x for x, y in zip(repeated, other)}
                    assert len(delta) == 1 and next(iter(delta)) in (-1, 1)
                    sign = next(iter(delta))
                    assert all((x, y) in [(-sign, 0), (0, sign)]
                               for x, y in zip(repeated, other))
                    size = sum(x != 0 for x in repeated)
                    assert (columns, size) in [(4, 1), (4, 2), (5, 1)]
                    kind = "mixed_{}_{}".format(columns, size)
                found[kind] = found.get(kind, 0)+1
                return
            for col in options:
                cost = sum(map(abs, col))
                if cost <= budget:
                    visit(prefix+(col,), budget-cost)
        visit((), 6)
    return {"columns": columns, "classified_matrices": found,
            "total": sum(found.values())}


def nonzero_D(b):
    Q = 5**b
    m = 3*Q
    fibre = [1+k*(Q//5) for k in range(5)]
    survivors = []
    for signs in product((-1, 1), repeat=5):
        top = []
        for u, sign in zip(fibre, signs):
            target = sign*u % Q
            top.append(next(x for x in (target, target+Q, target+2*Q) if x % 3 == 1))
        last = -sum(top) % m
        tup = tuple(sorted(top+[last]))
        if last and age_check(tup, m):
            assert len(set(signs)) == 1
            survivors.append(tup)
    assert len(survivors) == 2
    assert set(fibre+[-x % Q for x in fibre]).isdisjoint(
        {3*x % Q for x in fibre+[-x % Q for x in fibre]})
    return {"degree": m, "nonzero_D_sign_assignments": 32,
            "balanced_standard_survivors": survivors,
            "fibre_support_separation": True}


if __name__ == "__main__":
    for columns, expected in [(4, 66), (5, 36), (6, 6)]:
        result = shapes(columns)
        assert result["total"] == expected, result
        print(json.dumps(result), flush=True)
    for b in (2, 3, 4):
        print(json.dumps(nonzero_D(b)), flush=True)
        print(json.dumps(potentials(5, b)), flush=True)
