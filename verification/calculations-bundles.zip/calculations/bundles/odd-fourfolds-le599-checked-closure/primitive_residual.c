/* Primitive residual census, 3 <= m <= 599. All arrays are bounded by m.
   Each orbit has a coordinate gcd(a_i,m), a proper divisor of m. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define LIMIT 600
static int m, nu, u[LIMIT], residues[LIMIT][LIMIT];
static int seen[100][6], ns;
static unsigned long long candidates;
static int gcd(int a,int b){while(b){int r=a%b;a=b;b=r;}return a;}
static int cmp(const void *a,const void *b){return *(const int*)a-*(const int*)b;}
static int lex(const int *a,const int *b){for(int i=0;i<6;i++)if(a[i]!=b[i])return a[i]<b[i]?-1:1;return 0;}
static int hodge(const int *a,int n){for(int k=1;k<nu;k++){int s=0;for(int i=0;i<n;i++)s+=residues[k][a[i]];if(2*s!=n*m)return 0;}return 1;}
static int pair(const int *a){for(int i=0;i<6;i++)for(int j=i+1;j<6;j++)if(a[i]+a[j]==m)return 1;return 0;}
static int standard5(const int *a){
 if(m%5)return 0;
 int d=m/5;
 for(int omit=0;omit<6;omit++){
  int b[5],n=0,ok=1;
  for(int i=0;i<6;i++)if(i!=omit)b[n++]=a[i];
  for(int i=0;i<5;i++)for(int j=i+1;j<5;j++)if(b[i]==b[j]||b[i]%d!=b[j]%d)ok=0;
  if(ok&&d/gcd(b[0],d)>2&&((5*b[0]+a[omit])%m==0))return 1;
 }return 0;
}
static int surface_split(const int *a){
 for(int mask=1;mask<64;mask+=2){
  if(__builtin_popcount((unsigned)mask)!=3)continue;
  int b[4],c[4],nb=0,nc=0,s=0;
  for(int i=0;i<6;i++)if(mask>>i&1){b[nb++]=a[i];s+=a[i];}else c[nc++]=a[i];
  s%=m;if(!s)continue;b[3]=m-s;c[3]=s;
  if(hodge(b,4)&&hodge(c,4))return 1;
 }return 0;
}
static void record(const int *a){
 int best[6],b[6];memcpy(best,a,sizeof best);qsort(best,6,sizeof(int),cmp);
 for(int k=0;k<nu;k++){
  for(int i=0;i<6;i++)b[i]=residues[k][a[i]];
  qsort(b,6,sizeof(int),cmp);if(lex(b,best)<0)memcpy(best,b,sizeof best);
 }
 for(int i=0;i<ns;i++)if(!lex(best,seen[i]))return;
 if(ns==100){fputs("residual capacity exceeded\n",stderr);exit(2);}
 memcpy(seen[ns++],best,sizeof best);
 printf("RESIDUAL %d",m);for(int i=0;i<6;i++)printf(" %d",best[i]);puts("");fflush(stdout);
}
int main(int argc,char **argv){
 if(argc!=2||(m=atoi(argv[1]))<3||m>=LIMIT||m%2==0)return 2;
 clock_t start=clock();
 for(int t=1;t<m;t++)if(gcd(t,m)==1){u[nu]=t;for(int x=1;x<m;x++)residues[nu][x]=t*x%m;nu++;}
 int a[6];
 for(int g=1;g<m;g++)if(m%g==0){
  a[0]=g;
  for(a[1]=1;a[1]<m&&g+5*a[1]<=3*m;a[1]++)
   for(a[2]=a[1];a[2]<m&&g+a[1]+4*a[2]<=3*m;a[2]++)
    for(a[3]=a[2];a[3]<m&&g+a[1]+a[2]+3*a[3]<=3*m;a[3]++){
     int rest=3*m-g-a[1]-a[2]-a[3];
     int lo=rest-(m-1);if(lo<a[3])lo=a[3];
     for(a[4]=lo;2*a[4]<=rest;a[4]++){
      a[5]=rest-a[4];if(a[5]>=m)continue;candidates++;
      if(pair(a)||!hodge(a,6)||standard5(a))continue;
      int content=m;for(int i=0;i<6;i++)content=gcd(content,a[i]);
      if(content!=1||surface_split(a))continue;
      record(a);
     }
    }
 }
 printf("DONE %d units=%d candidates=%llu primitive_residuals=%d cpu_seconds=%.3f\n",m,nu,candidates,ns,(double)(clock()-start)/CLOCKS_PER_SEC);
 return 0;
}
