"""Independent finite checks of the global positive finite reduction.

Direct surface ages and exact Gaussian-integer Fourier sums; no old
census or checker is imported. One process, standard library only.
"""
from collections import Counter
from itertools import combinations, product
from math import gcd
import json
import time


def surface_census(m):
    units = [t for t in range(1, m) if gcd(t, m) == 1]
    half = [t for t in units if t < m/2]
    found = set()
    for g in range(1, m):
        if m % g:
            continue
        for b in range(g, m):
            if gcd(b, m) < g or b+g == m:
                continue
            for c in range(b, m):
                d = 2*m-g-b-c
                if not c <= d < m or gcd(c, m) < g or gcd(d, m) < g:
                    continue
                a = (g, b, c, d)
                if gcd(m, *a) != 1 or any(x+y == m for x, y in combinations(a, 2)):
                    continue
                if any(sum(t*x % m for x in a) != 2*m for t in half):
                    continue
                canonical = min(tuple(sorted(t*x % m for x in a)) for t in units)
                found.add(canonical)
    nonstandard = []
    for a in sorted(found):
        assert all(sum(t*x % m for x in a) == 2*m for t in units)
        standard = m % 3 == 0 and any(
            tuple(sorted([(x+k*m//3) % m for k in range(3)] + [-3*x % m])) == a
            for x in a if 3*x % m)
        if not standard:
            assert m in (15, 21), (m, a)
            nonstandard.append(a)
    return {"degree": m, "primitive_pair_free_surface_orbits": len(found),
            "non_3_standard_orbits": nonstandard}


def fifth_patterns():
    logarithm = {pow(2, k, 5): k for k in range(4)}
    rows = []
    for signs in product((-1, 1), repeat=4):
        A = [sum(signs[k-1] * (1j)**(-j*logarithm[k]) for k in range(1, 5))
             for j in (1, 2, 3)]
        plus = signs.count(1)
        if plus in (0, 4):
            assert all(a == 0 for a in A)
        elif plus == 2:
            assert any(a == 0 for a in A)
        else:
            assert all(a.real*a.real+a.imag*a.imag == 4 for a in A)
        rows.append({"signs": signs, "plus": plus,
                     "A": [[int(a.real), int(a.imag)] for a in A]})
    for signs in product((-1, 1), repeat=5):
        # Reduction modulo 1+X+...+X^4. A rational polynomial of
        # degree at most four vanishes at a primitive fifth root
        # exactly when these four exact remainder coefficients vanish.
        remainder = [x-signs[4] for x in signs[:4]]
        assert (not any(remainder)) == (len(set(signs)) == 1)
    return {"four_sign_patterns": rows, "five_sign_patterns_checked": 32,
            "quartic_squared_norm_identity": "|1-iz|^2+|1+iz|^2=4 for |z|=1"}


if __name__ == "__main__":
    start = time.monotonic()
    print(json.dumps(fifth_patterns()), flush=True)
    for m in (5, 7, 9, 15, 21, 25, 27, 33, 35, 39, 45, 63, 75, 105,
              135, 147, 165, 189, 195, 225, 231, 315, 525, 735, 945, 1155):
        print(json.dumps(surface_census(m)), flush=True)
    print(json.dumps({"status": "PASS", "elapsed_seconds": time.monotonic()-start}), flush=True)
