"""Independent finite checks of Theorem 7.8; standard library only.

The matrix search exhausts the stated mass bound. Potential searches exhaust
the norm bound up to unit dilation (one positive atom is normalized to 1).
These are finite calibrations, not a proof at arbitrary prime powers.
"""
from collections import Counter
from itertools import combinations, combinations_with_replacement, product
from math import gcd
import json


def age_check(tup, m):
    return all(2 * sum(t * x % m for x in tup) == len(tup) * m
               for t in range(1, m) if gcd(t, m) == 1)


def split_witness(tup, m):
    for ix in combinations(range(6), 3):
        left = tuple(tup[i] for i in ix)
        right = tuple(tup[i] for i in range(6) if i not in ix)
        s = sum(left) % m
        if s and age_check(left + (m-s,), m) and age_check(right + (s,), m):
            return [left + (m-s,), right + (s,)]
    raise AssertionError((m, tup))


def grids(columns):
    count = boundary = 0
    for a, b in product(range(-6, 7), repeat=2):
        options = [(v, v+a, v+b) for v in range(-6, 7)
                   if abs(v) + abs(v+a) + abs(v+b) <= 6]

        def visit(prefix, budget):
            nonlocal count, boundary
            if len(prefix) == columns:
                if budget == 6:
                    return
                count += 1
                if any(min(col) > 0 or max(col) < 0 for col in prefix):
                    return
                boundary += 1
                if columns >= 6:
                    assert columns == 6
                    assert all(col == prefix[0] for col in prefix)
                    assert sum(map(abs, prefix[0])) == 1
                return
            for col in options:
                cost = sum(map(abs, col))
                if cost <= budget:
                    visit(prefix + (col,), budget-cost)
        visit((), 6)
    if columns >= 7:
        assert boundary == 0
    return {"grid": [3, columns], "nonzero_split_functions_mass_le_6": count,
            "without_a_same_sign_three_line": boundary}


def potentials(q, exponent):
    Q = q ** exponent
    m = 3 * Q
    units = [x for x in range(1, Q) if gcd(x, Q) == 1]
    models = 0
    short = {}
    for r in (1, 2, 3):
        for tail in combinations_with_replacement(units, r-1):
            atoms = (1,) + tail
            if any(Q-x in atoms for x in atoms):
                continue
            v = Counter(atoms)
            for x in atoms:
                v[Q-x] -= 1
            delta = Counter()
            for x, value in v.items():
                delta[x * pow(3, -1, Q) % Q] += value
                delta[x] -= value
            d = sum(map(abs, delta.values())) // 2
            models += 1
            if 2*r+d > 6:
                continue
            # Build independently in actual residues, rather than reusing a tuple formula.
            tup = []
            for x in range(1, m):
                if x % 3 and x % q:
                    value = v[x % Q]
                elif x % 3 == 0 and x % q:
                    value = delta[x // 3]
                else:
                    value = 0
                tup.extend([x] * max(0, value))
            tup = tuple(tup)
            assert len(tup) == 2*r+d
            assert age_check(tup, m), (m, atoms, tup)
            if len(tup) == 4:
                assert r == 1 and d == 2
                witness = "surface; a remaining balanced pair contradicts pair-freeness"
            else:
                assert len(tup) == 6 and r == 2 and d == 2
                witness = split_witness(tup, m)
            short[tup] = {"atoms": atoms, "length": len(tup), "tuple": tup,
                          "surface_split": witness}
    kernel = [x for x in units if x % (Q//q) == 1]
    assert len(kernel) == q
    assert set(kernel).isdisjoint({Q-x for x in kernel})
    return {"degree": m, "q": q, "exponent": exponent,
            "normalized_potential_models": models, "fibre_size": len(kernel),
            "minimum_nonzero_even_or_odd_invariant_mass": 2*len(kernel),
            "short_blocks": list(short.values())}


if __name__ == "__main__":
    for columns in (4, 5, 6, 7, 10):
        print(json.dumps(grids(columns)), flush=True)
    for q, exponent in ((7, 2), (11, 2), (13, 2), (17, 2), (7, 3), (19, 2)):
        print(json.dumps(potentials(q, exponent)), flush=True)
