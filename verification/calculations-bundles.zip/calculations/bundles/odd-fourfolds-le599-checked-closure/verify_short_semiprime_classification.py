"""Independent sparse-potential check of Theorem 7.3; standard library only.

Print every pair-free length-six tuple obtained, with a direct age check
and a surface-split/standard witness. This finite check does not prove
the conductor-uniform theorem. No earlier checker or census is imported.
"""
from collections import Counter
from itertools import combinations
from math import gcd
import json


def vectors(size, budget, parity):
    if size == 0:
        yield ()
        return
    for magnitude in range(parity, budget - parity * (size - 1) + 1, 2):
        for value in ((0,) if magnitude == 0 else (magnitude, -magnitude)):
            for rest in vectors(size - 1, budget - magnitude, parity):
                yield (value,) + rest


def odd(values, prime):
    result = {}
    for residue, value in enumerate(values, 1):
        result[residue] = value
        result[prime - residue] = -value
    return result


def hodge(tup, degree):
    return all(2 * sum(t * x % degree for x in tup) == len(tup) * degree
               for t in range(1, degree) if gcd(t, degree) == 1)


def witness(tup, degree):
    for indices in combinations(range(6), 3):
        left = tuple(tup[i] for i in indices)
        right = tuple(tup[i] for i in range(6) if i not in indices)
        residue = sum(left) % degree
        if residue and hodge(left + (degree - residue,), degree) and hodge(
                right + (residue,), degree):
            return {"surface_left": left + (degree - residue,),
                    "surface_right": right + (residue,)}
    if degree % 5 == 0:
        step = degree // 5
        for parameter in range(1, degree):
            if step // gcd(parameter, step) <= 2:
                continue
            standard = tuple((parameter + j * step) % degree for j in range(5))
            standard += (-5 * parameter % degree,)
            if Counter(standard) == Counter(tup):
                return {"standard_prime": 5, "parameter": parameter}
    return None


def run(p, q):
    degree = p * q
    attempts = 0
    tuples = set()
    residuals = set()
    for parity in (0, 1):
        for row in vectors((p - 1) // 2, 12 // (q - 1), parity):
            for column in vectors((q - 1) // 2, 12 // (p - 1), parity):
                attempts += 1
                u, v = odd(row, p), odd(column, q)
                f = {}
                for x in range(1, degree):
                    if x % p and x % q:
                        twice = u[x % p] + v[x % q]
                    elif x % q == 0:
                        y = x // q
                        twice = u[q * y % p] - u[y]
                    else:
                        z = x // p
                        twice = v[p * z % q] - v[z]
                    assert twice % 2 == 0
                    f[x] = twice // 2
                tup = tuple(x for x in range(1, degree) for _ in range(max(0, f[x])))
                if len(tup) != 6:
                    continue
                assert tup not in tuples
                tuples.add(tup)
                assert all(f[x] == -f[degree - x] for x in f)
                assert hodge(tup, degree), (degree, tup)
                result = witness(tup, degree)
                canonical = min(tuple(sorted(t * x % degree for x in tup))
                                for t in range(1, degree) if gcd(t, degree) == 1)
                if result is None:
                    residuals.add(canonical)
                print(json.dumps({"degree": degree, "tuple": tup,
                                  "doubled_row": row, "doubled_column": column,
                                  "witness": result, "orbit": canonical}))
    expected = {
        33: {(1, 4, 16, 22, 25, 31)},
        39: {(1, 7, 16, 22, 34, 37), (1, 14, 16, 22, 29, 35)},
    }.get(degree, set())
    assert residuals == expected, (degree, residuals)
    print(json.dumps({"summary": degree, "p": p, "q": q,
                      "potential_models": attempts, "pair_free_sextuples": len(tuples),
                      "residuals": sorted(residuals)}))


if __name__ == "__main__":
    for primes in ((3, 5), (3, 7), (3, 11), (3, 13),
                   (3, 17), (3, 19), (3, 23), (3, 31), (3, 43),
                   (5, 7), (5, 11), (5, 17)):
        run(*primes)
