"""Enumerate the unresolved R3 degrees above 599, with the original controls.

Run in this directory on the allocated compute node:
  python3 extend_residual_census.py > extension-output.txt 2>&1
Uses one CPU, the standard library and the unchanged C enumerator (limit 2001).
"""
import hashlib
import platform
import subprocess
import sys
import time
from pathlib import Path

import run_independent_census as checker


def prime_support(n):
    result = []
    p = 3
    while p*p <= n:
        if n % p == 0:
            result.append(p)
            while n % p == 0:
                n //= p
        p += 2
    if n > 1:
        result.append(n)
    return result


if __name__ == "__main__":
    start = time.monotonic()
    extra = [m for m in range(601, 2002, 2) if m % 3 == 0
             and (prime_support(m) == [3, 5] or len(prime_support(m)) >= 3)]
    checker.DEGREES = sorted(set(checker.DEGREES + extra))
    print("EXTENSION_START utc=" + time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    print("HOST", platform.node(), "PYTHON", sys.version.replace("\n", " "))
    for name in ["residual_pair_triple.c", "run_independent_census.py", __file__]:
        print("SOURCE_SHA256", hashlib.sha256(Path(name).read_bytes()).hexdigest(), name)
    print("EXTRA_DEGREES", *extra)
    print("ALL_DEGREES", *checker.DEGREES, flush=True)
    subprocess.run(["cc", "--version"], check=True)
    subprocess.run(["cc", "-O3", "-std=c11", "-Wall", "-Wextra",
                    "residual_pair_triple.c", "-o", "extension-census"], check=True)
    result = subprocess.run(["./extension-census"] + list(map(str, checker.DEGREES)),
                            check=True, stdout=subprocess.PIPE, text=True)
    print(result.stdout, end="", flush=True)
    checker.verify(result.stdout)
    print("EXTENSION_END elapsed_seconds={:.6f}".format(time.monotonic()-start), flush=True)
