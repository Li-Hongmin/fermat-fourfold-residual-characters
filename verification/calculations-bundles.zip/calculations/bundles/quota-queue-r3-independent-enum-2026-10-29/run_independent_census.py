"""Compile/run the independent C census and check it using direct Python definitions.

Reproduce in this directory (one CPU, standard library only):
  python3 run_independent_census.py --raw raw-output.txt > raw-output.txt 2>&1
The raw path must name the redirected output, not an existing certificate.
"""
import argparse
import hashlib
import itertools
import math
import platform
import re
import subprocess
import sys
import time
from pathlib import Path

SEMIPRIMES = [15, 21, 33, 35, 39, 51, 55, 57, 65, 69, 77, 85,
              87, 91, 93, 95, 111, 115, 119, 123, 129, 133, 141, 143]
POWERS = sorted({p**e for p, bound in [(3, 6), (5, 4), (7, 3), (11, 2),
                                     (13, 2), (17, 2), (19, 2), (23, 2)]
                 for e in range(1, bound+1)})
CONTROLS = [45, 99, 105, 117, 135]
DEGREES = sorted(set(SEMIPRIMES + POWERS + CONTROLS + [603, 609]))


def units(m):
    return [t for t in range(1, m) if math.gcd(t, m) == 1]


def hodge(a, m):
    return all(sum(t*x % m for x in a) == len(a)*m//2 for t in units(m))


def canonical(a, m):
    return min(tuple(sorted(t*x % m for x in a)) for t in units(m))


def has_pair(a, m):
    return any(x+y == m for x, y in itertools.combinations(a, 2))


def dec(a, m):
    if has_pair(a, m):
        return True
    for indices in itertools.combinations(range(6), 3):
        left = tuple(a[j] for j in indices)
        right = tuple(a[j] for j in range(6) if j not in indices)
        s = sum(left) % m
        if s and hodge(left + (m-s,), m) and hodge(right + (s,), m):
            return True
    return False


def standards(m):
    if m % 5:
        return set()
    d = m//5
    return {tuple(sorted(tuple(i+k*d for k in range(5)) + ((-5*i) % m,)))
            for i in range(1, d) if (-5*i) % m}


def direct_nonpair_orbits(m):
    """No divisor normalization, fingerprints, or inherited enumeration code."""
    result = set()
    for a in itertools.combinations_with_replacement(range(1, m), 6):
        if sum(a) == 3*m and not has_pair(a, m) and hodge(a, m):
            result.add(canonical(a, m))
    return result


def verify(raw):
    rows = {m: {} for m in DEGREES}
    done = {}
    orbit_pattern = re.compile(
        r"ORBIT m=(\d+) tuple=([\d,]+) content=(\d+) conductor=(\d+) "
        r"dec_mask=(\d+) std5=(\d+) residual=(\d+)")
    for line in raw.splitlines():
        if line.startswith("ORBIT "):
            match = orbit_pattern.fullmatch(line)
            assert match, line
            m, values, gcd, conductor, mask, std, residual = match.groups()
            m = int(m)
            a = tuple(map(int, values.split(",")))
            flags = tuple(map(int, (gcd, conductor, mask, std, residual)))
            assert a not in rows[m], ("duplicate orbit", m, a)
            rows[m][a] = flags
        elif line.startswith("DONE "):
            fields = dict(field.split("=") for field in line.split()[1:])
            m = int(fields["m"])
            assert m not in done, ("duplicate completion", m)
            done[m] = fields
    assert set(done) == set(DEGREES), (set(done), DEGREES)
    total_residual = 0
    for m in DEGREES:
        standard_set = standards(m)
        ndec = nstd = nres = nprimitive = 0
        for a, (gcd, conductor, mask, std, residual) in rows[m].items():
            assert len(a) == 6 and 0 < min(a) <= max(a) < m
            assert a == tuple(sorted(a)) and a == canonical(a, m)
            assert not has_pair(a, m) and hodge(a, m)
            assert gcd == math.gcd(m, *a) and conductor == m//gcd
            is_dec, is_std = dec(a, m), a in standard_set
            assert bool(mask) == is_dec and bool(std) == is_std, (m, a)
            if mask:
                assert mask & 1 and bin(mask).count("1") == 3
                left = tuple(a[j] for j in range(6) if mask & (1 << j))
                right = tuple(a[j] for j in range(6) if not mask & (1 << j))
                s = sum(left) % m
                assert s and hodge(left + (m-s,), m) and hodge(right + (s,), m)
            assert bool(residual) == (not is_dec and not is_std)
            ndec += is_dec
            nstd += not is_dec and is_std
            nres += residual
            nprimitive += residual and gcd == 1
        expected = (len(rows[m]), ndec, nstd, nres, nprimitive)
        actual = tuple(int(done[m][k]) for k in
                       ("nonpair_orbits", "dec", "std5_only", "residual",
                        "primitive_residual"))
        assert expected == actual, (m, expected, actual)
        total_residual += nres
    for m in [3, 5, 7, 9, 15, 21, 25, 33, 39]:
        brute = direct_nonpair_orbits(m)
        assert brute == set(rows[m]), (m, brute ^ set(rows[m]))
        print("BRUTE_FORCE_PASS m={} nonpair_orbits={}".format(m, len(brute)), flush=True)
    seeds = {
        33: {(1, 4, 16, 22, 25, 31)},
        39: {(1, 7, 16, 22, 34, 37), (1, 14, 16, 22, 29, 35)},
        45: {(1, 19, 20, 28, 30, 37)},
        105: {(1, 22, 43, 64, 90, 95), (3, 24, 50, 66, 85, 87)},
    }
    for m in DEGREES:
        expected = {canonical(tuple(x*(m//d) for x in a), m)
                    for d, tuples in seeds.items() if m % d == 0 for a in tuples}
        observed = {a for a, flags in rows[m].items() if flags[-1]}
        # This assertion compares independently enumerated output with the
        # requested hypothesis; seeds do not enter the C search or predicates.
        assert observed == expected, (m, observed, expected)
        print("CHECK_PASS m={} residual={} primitive_residual={}".format(
            m, len(observed), sum(math.gcd(m, *a) == 1 for a in observed)), flush=True)
    print("VERIFIED degrees={} canonical_nonpair_orbits={} residual_orbits={} "
          "full_unit_predicates=PASS direct_small_census=PASS".format(
              len(DEGREES), sum(map(len, rows.values())), total_residual), flush=True)


def run():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw", type=Path, required=True)
    args = parser.parse_args()
    start = time.monotonic()
    print("INDEPENDENT_R3_CENSUS_START utc=" + time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    print("HOST " + platform.node() + " PLATFORM " + platform.platform())
    print("PYTHON " + sys.version.replace("\n", " "))
    for filename in ["residual_pair_triple.c", "run_independent_census.py"]:
        print("SOURCE_SHA256 {} {}".format(hashlib.sha256(Path(filename).read_bytes()).hexdigest(), filename))
    print("SEMIPRIMES " + " ".join(map(str, SEMIPRIMES)))
    print("PRIME_POWERS " + " ".join(map(str, POWERS)))
    print("CONTROLS " + " ".join(map(str, CONTROLS)))
    sys.stdout.flush()
    subprocess.run(["cc", "--version"], check=True)
    command = ["cc", "-O3", "-std=c11", "-Wall", "-Wextra", "residual_pair_triple.c", "-o", "census"]
    print("COMPILE " + " ".join(command), flush=True)
    subprocess.run(command, check=True)
    print("EXECUTE ./census " + " ".join(map(str, DEGREES)), flush=True)
    subprocess.run(["./census"] + list(map(str, DEGREES)), check=True)
    sys.stdout.flush()
    verify(args.raw.read_text())
    print("INDEPENDENT_R3_CENSUS_END elapsed_seconds={:.6f}".format(time.monotonic()-start), flush=True)


if __name__ == "__main__":
    run()
