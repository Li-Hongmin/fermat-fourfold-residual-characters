# R9 independent large-degree check (2026-11-04)

Status: finite observations, **not premises** of Theorem A. They test the
counting formula |R(m)| = 1[33|m] + 2·1[39|m] + 1[45|m] + 2·1[105|m] and the
six-seed residual equality at degrees beyond the exhaustive base.

## Method
`mitm6.c` (new code, shares nothing with enum6.c, hs_enum3.c, cen.c or en.c)
enumerates, for odd m, every pair-free sextuple with age 3 at every unit
that contains a proper divisor g of m. Completeness: any orbit member can
be scaled by a unit so that its first entry becomes gcd(a_1, m), which is
a proper divisor. Split A={g,x,y}, B={u<=v<=w}; candidates are matched by a
hash of the sum and 16 fixed pseudo-random unit ages, then every match is
verified at **all** units and checked for cross inverse pairs. Hash
collisions can only add candidates, never remove one, because each B
triple scans all table entries with an equal hash key.
`classify_r9.py` re-verifies each row in Python, takes canonical unit
orbits and classifies by Std5 → Dec (all ten 3+3 splits) → residual, then
compares with the seed inflations (exit nonzero on mismatch).
`compare_prior.py` compares with verbatim copies of the earlier hs_enum3 (OMEN) and cen.c runs in `prior-runs/`.

## Runs
- Local (macOS, Apple clang, `-isysroot MacOSX26.5.sdk`): all 52 odd m in
  3..105 give 57 pair-free orbits = 15 Std5 + 35 Dec + 7 residual, the
  residuals being the six seeds and the degree-99 inflation; also 117, 135,
  165, 195, 225, 231, 273, 315, 345, 385 (`results/local-smoke/`).
- TSUBAME 4.0 batch array job 9250540 (qsub, cpu_8, h_rt 1:00:00, GCC 11.5,
  Python 3.9; 10 tasks, 1 min–35 min wall, ≤6.3 GB RSS):
  m = 1155, 1365, 1785, 1995, 2145, 2415, 2625, 2835, 3003, 3315.
  Raw rows, /usr/bin/time output, classifications and logs are in
  `results/tsubame-9250540/`. Every degree: residual set = seed inflations,
  residual count = formula (3,4,2,2,3,2,2,3,3,2).
- `results/compare-prior-output.txt`: residual sets and Std5/Dec/residual
  counts agree with hs_enum3 at 1785, 2415, 2625, 2835, 3003, 3315 and with
  cen.c residual sets at 1155, 1365, 1785, 1995, 2145, 2415, 2625, 3003.

## Reproduce
```sh
cc -O2 -o mitm6 mitm6.c          # macOS: add -isysroot <SDK>
./mitm6 1785 > rows_1785.txt 2> summary_1785.txt
python3 classify_r9.py 1785 rows_1785.txt
python3 compare_prior.py results/tsubame-9250540/results
```
Degrees above ~1500 need minutes and several GB; run them through a
scheduler (`tsubame_r9_array.sh`), not on a login node.
