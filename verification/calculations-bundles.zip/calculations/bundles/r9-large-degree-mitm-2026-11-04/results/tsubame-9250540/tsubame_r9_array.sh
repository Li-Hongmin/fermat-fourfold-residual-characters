#!/bin/bash
#$ -cwd
#$ -l cpu_8=1
#$ -l h_rt=1:00:00
#$ -N hodgeR9mitm
#$ -t 1-10
#$ -j y
#$ -o /gs/bs/tga-satolab-gtex/lihongmin/hodge-r9-largedeg-20261104/logs/
# R9 independent large-degree check: one degree per array task, batch only.
R=/gs/bs/tga-satolab-gtex/lihongmin/hodge-r9-largedeg-20261104
cd $R; mkdir -p results logs bin
DEG=(1155 1365 1785 1995 2145 2415 2625 2835 3003 3315)
m=${DEG[$((SGE_TASK_ID-1))]}
echo "JOB $JOB_ID task $SGE_TASK_ID m=$m host $(hostname) start $(date -Is)"
cc --version | head -1; python3 --version
cc -O2 -o bin/mitm6_$SGE_TASK_ID mitm6.c || exit 2
/usr/bin/time -v bin/mitm6_$SGE_TASK_ID $m > results/rows_$m.txt 2> results/summary_$m.txt; echo "enum rc=$?"
python3 classify_r9.py $m results/rows_$m.txt > results/class_$m.json; echo "classify rc=$?"
cat results/class_$m.json | cut -c1-400
echo "end $(date -Is)"
