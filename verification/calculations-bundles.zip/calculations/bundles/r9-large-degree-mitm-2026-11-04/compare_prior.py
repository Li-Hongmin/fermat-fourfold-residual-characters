"""Compare R9 mitm6 results with earlier, separately written large-degree runs:
hs_enum3 (xcheck-hodge-thm720, OMEN) and cen.c (xcheck-hodge-r3full).  Residual
tuples are canonicalized here (cen.c raw lines can repeat one orbit; see its
review report).  usage: python3 compare_prior.py results/tsubame-9250540/results"""
import sys, json, math, re, os
B=os.path.dirname(os.path.abspath(__file__))
def canon(t,m):
    return min(tuple(sorted((u*x)%m for x in t)) for u in range(1,m) if math.gcd(u,m)==1)
prior={}
for line in open(B+'/prior-runs/hs_enum3/omen-large-1785-2415-2625-2835-3003-3315.txt'):
    if line.startswith('RESIDUAL'):
        m=int(re.search(r'm=(\d+)',line).group(1)); t=tuple(map(int,line.split()[-6:]))
        prior.setdefault(('hs_enum3',m),set()).add(canon(t,m))
    if line.startswith('SUMMARY'):
        m=int(re.search(r'm=(\d+)',line).group(1)); prior.setdefault(('hs_enum3',m),set())
        prior[('hs_enum3_counts',m)]={k:int(v) for k,v in re.findall(r'(orbit_classes|std5|dec|residual_orbits)=(\d+)',line)}
for m in (1155,1365,1785,1995,2145,2415,2625,3003):
    for f in ('out_%d.txt'%m,'big_%d.txt'%m):
        p=B+'/prior-runs/cen_c/'+f
        if os.path.exists(p):
            s=prior.setdefault(('cen.c',m),set())
            for line in open(p):
                if line.startswith('R '): s.add(canon(tuple(map(int,line.split()[2:8])),m))
ok=True
for f in sorted(os.listdir(sys.argv[1])):
    if not f.startswith('class_'): continue
    j=json.load(open(os.path.join(sys.argv[1],f))); m=j['m']; mine={tuple(r) for r in j['residuals']}
    for src in ('hs_enum3','cen.c'):
        if (src,m) in prior:
            same=prior[(src,m)]==mine; ok&=same
            print(m,src,'residual sets','MATCH' if same else 'DIFFER',len(mine))
    c=prior.get(('hs_enum3_counts',m))
    if c:
        same=(c['orbit_classes'],c['std5'],c['dec'],c['residual_orbits'])==(j['orbits'],j['std5'],j['dec'],j['residual'])
        ok&=same; print(m,'hs_enum3 counts',c,'MATCH' if same else 'DIFFER')
print('ALL_MATCH' if ok else 'MISMATCH'); sys.exit(0 if ok else 1)
