/* mitm6.c -- independent meet-in-the-middle enumerator (R9, 2026-11-04).
 * Prints every pair-free sextuple of nonzero residues mod m (m odd) with
 * age 3 at every unit t, among those containing a proper divisor g of m
 * (every unit orbit contains such a member: scale a_1 to gcd(a_1,m)).
 * Split: A = {g, x, y} (x<=y), B = {u<=v<=w}; key = (sum, <t.>-sums at K
 * fixed units).  Complementary keys are matched through a hash table; each
 * match is fully verified at ALL units before printing.  Output rows are
 * sorted sextuples (duplicates allowed; dedup/orbits are done in Python).
 * Written from scratch; shares no code with enum6.c, hs_enum3.c or en.c. */
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#ifndef K
#define K 16
#endif
static int m, nu, *U, T[K];
static int gcd(int a,int b){while(b){int t=a%b;a=b;b=t;}return a;}
typedef struct { uint64_t h; int g,x,y; } Ent;
static Ent *tab; static uint64_t cap;
static void key3(int a,int b,int c,int *k){ k[0]=a+b+c; for(int i=0;i<K;i++){int t=T[i];k[i+1]=(t*a)%m+(t*b)%m+(t*c)%m;} }
static uint64_t hk(const int *k){ uint64_t h=1469598103934665603ULL; for(int i=0;i<=K;i++){h^=(uint64_t)k[i]; h*=1099511628211ULL; h^=h>>29;} return h|1; }
static int full(const int *s){ for(int i=0;i<nu;i++){long t=U[i],S=0;for(int j=0;j<6;j++)S+=(t*s[j])%m; if(S!=3L*m)return 0;} return 1; }
static int cmp(const void*a,const void*b){return *(int*)a-*(int*)b;}
int main(int argc,char**argv){
  m=atoi(argv[1]); U=malloc(sizeof(int)*m); nu=0;
  for(int t=1;t<m;t++) if(gcd(t,m)==1) U[nu++]=t;
  /* K fixed test units, spread through U (excluding t=1, already the sum) */
  /* deterministic pseudo-random distinct test units (LCG), excluding 1 */
  { uint64_t r=0x9E3779B97F4A7C15ULL^(uint64_t)m; for(int i=0;i<K;i++){ int ok; do{ r=r*6364136223846793005ULL+1442695040888963407ULL; T[i]=U[1+(int)((r>>33)%(uint64_t)(nu-1))]; ok=1; if(i<nu-1) for(int j=0;j<i;j++) if(T[j]==T[i]) ok=0; }while(!ok); } }
  long nA=0; for(int g=1;g<m;g++) if(m%g==0) for(int x=1;x<m;x++) for(int y=x;y<m;y++) nA++;
  cap=1; while(cap<2*(uint64_t)nA) cap<<=1; tab=calloc(cap,sizeof(Ent));
  long stored=0;
  for(int g=1;g<m;g++) if(m%g==0) for(int x=1;x<m;x++) { if(g+x==m) continue;
    for(int y=x;y<m;y++){ if(g+y==m||x+y==m) continue; int k[K+1]; key3(g,x,y,k);
      if(k[0]>3*m-3) continue;  /* B sum is at least 3 */
      uint64_t h=hk(k), i=h&(cap-1); while(tab[i].h) i=(i+1)&(cap-1);
      tab[i].h=h; tab[i].g=g; tab[i].x=x; tab[i].y=y; stored++; } }
  long matches=0, crosspair=0, verified=0, printed=0;
  for(int u=1;u<m;u++) for(int v=u;v<m;v++){ if(u+v==m) continue;
    for(int w=v;w<m;w++){ if(u+w==m||v+w==m) continue;
      int k[K+1]; key3(u,v,w,k); int c[K+1]; for(int i=0;i<=K;i++) c[i]=3*m-k[i];
      if(c[0]<3) break;
      uint64_t h=hk(c), i=h&(cap-1);
      while(tab[i].h){ if(tab[i].h==h){ matches++;
          int s[6]={tab[i].g,tab[i].x,tab[i].y,u,v,w}; int bad=0;
          for(int p=0;p<3&&!bad;p++) for(int q=3;q<6;q++) if(s[p]+s[q]==m){bad=1;break;}
          if(bad){crosspair++;} else if(full(s)){ verified++; qsort(s,6,sizeof(int),cmp);
            printf("%d %d %d %d %d %d\n",s[0],s[1],s[2],s[3],s[4],s[5]); printed++; } }
        i=(i+1)&(cap-1); } } }
  fprintf(stderr,"SUMMARY m=%d units=%d K=%d Aentries=%ld matches=%ld crosspair=%ld verified=%ld\n",m,nu,K,stored,matches,crosspair,verified);
  return 0; }
