Verbatim copies (byte-identical) of earlier, separately written runs, used only by compare_prior.py:
- hs_enum3/omen-large-1785-2415-2625-2835-3003-3315.txt  <- calculations/bundles/xcheck-hodge-thm720-2026-10-29/results/ (git-tracked, OMEN run)
- cen_c/{out,big}_*.txt <- calculations/bundles/xcheck-hodge-r3full-2026-10-30/census-out/ (xcheck-r3full review, 2026-10-30).
  cen.c's raw R-lines may list one orbit twice (memcmp canonicalization; documented in
  reviews/quota-queue-xcheck-hodge-r3full-2026-10-30.md); compare_prior.py re-canonicalizes.
