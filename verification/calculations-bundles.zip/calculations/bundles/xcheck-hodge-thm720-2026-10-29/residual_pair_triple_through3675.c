/* Independent finite census from the definitions, without inherited code.
 * Build: cc -O3 -std=c11 -Wall -Wextra residual_pair_triple.c -o census
 * Run: ./census 33 39 603 609
 * Exact uint64_t fingerprints are necessary filters; every match is checked
 * at every unit (one from each conjugate pair). Collisions cannot lose tuples.
 */
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct { uint64_t key; int b, c, next; } Pair;
static int m, nu, *residue, *content;
static uint64_t *fingerprint, target;

static int gcd_int(int a, int b) {
    while (b) { int r = a % b; a = b; b = r; }
    return a;
}

static uint64_t mix(uint64_t z) {
    z = (z ^ (z >> 30)) * UINT64_C(0xbf58476d1ce4e5b9);
    z = (z ^ (z >> 27)) * UINT64_C(0x94d049bb133111eb);
    return z ^ (z >> 31);
}

static void sort6(int *a) {
    for (int i = 1; i < 6; ++i) {
        int x = a[i], j = i;
        while (j && a[j-1] > x) { a[j] = a[j-1]; --j; }
        a[j] = x;
    }
}

static int is_hodge(const int *a, int n) {
    for (int j = 0; j < nu; ++j) {
        int sum = 0;
        for (int k = 0; k < n; ++k) sum += residue[j*m + a[k]];
        if (sum != (n/2)*m) return 0;
    }
    return 1;
}

static int is_canonical(const int *a) {
    for (int t = 1; t < m; ++t) if (content[t] == 1) {
        int b[6];
        for (int k = 0; k < 6; ++k) b[k] = (t*a[k]) % m;
        sort6(b);
        for (int k = 0; k < 6; ++k) {
            if (b[k] < a[k]) return 0;
            if (b[k] > a[k]) break;
        }
    }
    return 1;
}

/* A mask with three bits, including bit zero; both surface tuples checked. */
static int split_mask(const int *a) {
    for (int i = 1; i < 5; ++i) for (int j = i+1; j < 6; ++j) {
        int mask = 1 | (1 << i) | (1 << j);
        int s = (a[0] + a[i] + a[j]) % m;
        if (!s) continue;
        int left[4], right[4], nl = 0, nr = 0;
        for (int k = 0; k < 6; ++k) {
            if (mask & (1 << k)) left[nl++] = a[k];
            else right[nr++] = a[k];
        }
        left[3] = m-s; right[3] = s;
        if (is_hodge(left, 4) && is_hodge(right, 4)) return mask;
    }
    return 0;
}

static int is_standard5(const int *a) {
    if (m % 5) return 0;
    int step = m/5;
    for (int omit = 0; omit < 6; ++omit) {
        int v[5], n = 0, good = 1;
        for (int j = 0; j < 6; ++j) if (j != omit) v[n++] = a[j];
        if (v[0] >= step || (a[omit] + 5*v[0]) % m) continue;
        for (int j = 1; j < 5; ++j)
            if (v[j] != v[0] + j*step) good = 0;
        if (good) return 1;
    }
    return 0;
}

static int has_pair(const int *a) {
    for (int i = 0; i < 6; ++i) for (int j = i+1; j < 6; ++j)
        if (a[i] + a[j] == m) return 1;
    return 0;
}

static void census(int degree) {
    clock_t start = clock();
    m = degree; nu = 0; target = 0;
    content = calloc((size_t)m, sizeof(*content));
    residue = calloc((size_t)m*m, sizeof(*residue));
    fingerprint = calloc((size_t)m, sizeof(*fingerprint));
    size_t capacity = (size_t)m*(m-1)/2, buckets = 1;
    while (buckets < (size_t)m*m) buckets *= 2;
    Pair *pairs = malloc(capacity*sizeof(*pairs));
    int *head = malloc(buckets*sizeof(*head));
    if (!content || !residue || !fingerprint || !pairs || !head) {
        fprintf(stderr, "Allocation failure at m=%d\n", m); exit(2);
    }
    for (int a = 1; a < m; ++a) content[a] = gcd_int(a, m);
    for (int t = 1; t <= m/2; ++t) if (content[t] == 1) {
        uint64_t weight = mix(UINT64_C(0x9e3779b97f4a7c15)*(uint64_t)t);
        target += weight*(uint64_t)(3*m);
        for (int a = 1; a < m; ++a) {
            int r = (t*a) % m;
            residue[nu*m + a] = r;
            fingerprint[a] += weight*(uint64_t)r;
        }
        ++nu;
    }
    uint64_t probes = 0, exact = 0, hodge = 0, orbits = 0;
    uint64_t dec = 0, std_only = 0, residual = 0, primitive = 0;
    printf("BEGIN m=%d half_units=%d memory_bytes=%zu\n", m, nu,
        (size_t)m*sizeof(*content) + (size_t)m*m*sizeof(*residue) +
        (size_t)m*sizeof(*fingerprint) + capacity*sizeof(*pairs) +
        buckets*sizeof(*head));
    for (int g = 1; g < m; ++g) if (m % g == 0) {
        for (size_t h = 0; h < buckets; ++h) head[h] = -1;
        int count = 0;
        for (int b = g; b < m; ++b) if (content[b] >= g && b+g != m)
            for (int c = b; c < m; ++c) {
                if (content[c] < g || b+c == m || c+g == m) continue;
                uint64_t key = fingerprint[b] + fingerprint[c];
                size_t h = mix(key) & (buckets-1);
                pairs[count] = (Pair){key, b, c, head[h]};
                head[h] = count++;
            }
        for (int d = g; d < m; ++d) if (content[d] >= g && d+g != m)
            for (int e = d; e < m; ++e) {
                if (content[e] < g || d+e == m || e+g == m) continue;
                int lo = 3*m-g-3*d-e, hi = 3*m-3*g-d-e;
                if (lo < e) lo = e;
                if (hi >= m) hi = m-1;
                for (int f = lo; f <= hi; ++f) {
                    if (content[f] < g || d+f == m || e+f == m || f+g == m)
                        continue;
                    ++probes;
                    uint64_t key = target - fingerprint[g] - fingerprint[d]
                                         - fingerprint[e] - fingerprint[f];
                    size_t h = mix(key) & (buckets-1);
                    for (int k = head[h]; k != -1; k = pairs[k].next) {
                        Pair p = pairs[k];
                        if (p.key != key || p.c > d || g+p.b+p.c+d+e+f != 3*m)
                            continue;
                        int a[6] = {g, p.b, p.c, d, e, f};
                        if (has_pair(a)) continue;
                        ++exact;
                        if (!is_hodge(a, 6)) continue;
                        ++hodge;
                        if (!is_canonical(a)) continue;
                        ++orbits;
                        int gcd = m;
                        for (int j = 0; j < 6; ++j) gcd = gcd_int(gcd, a[j]);
                        int split = split_mask(a), standard = is_standard5(a);
                        if (split) ++dec;
                        else if (standard) ++std_only;
                        else { ++residual; if (gcd == 1) ++primitive; }
                        printf("ORBIT m=%d tuple=%d,%d,%d,%d,%d,%d content=%d "
                               "conductor=%d dec_mask=%d std5=%d residual=%d\n",
                            m, g, p.b, p.c, d, e, f, gcd, m/gcd, split,
                            standard, !split && !standard);
                    }
                }
            }
    }
    printf("DONE m=%d probes=%"PRIu64" exact=%"PRIu64" hodge=%"PRIu64
           " nonpair_orbits=%"PRIu64" dec=%"PRIu64" std5_only=%"PRIu64
           " residual=%"PRIu64" primitive_residual=%"PRIu64" cpu_seconds=%.6f\n",
        m, probes, exact, hodge, orbits, dec, std_only, residual, primitive,
        (double)(clock()-start)/CLOCKS_PER_SEC);
    fflush(stdout);
    free(head); free(pairs); free(fingerprint); free(residue); free(content);
}

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "Usage: %s odd_degree ...\n", argv[0]); return 2; }
    for (int j = 1; j < argc; ++j) {
        char *end;
        long degree = strtol(argv[j], &end, 10);
        if (!*argv[j] || *end || degree < 3 || degree > 3675 || degree % 2 == 0) {
            fprintf(stderr, "Expected an odd degree in [3,3675]: %s\n", argv[j]);
            return 2;
        }
        census((int)degree);
    }
    return 0;
}
