"""Check the R4 census outputs using direct full-unit definitions.

Run from this directory: python3 verify_r4_census.py [results-directory]
The C census supplies completeness; this program checks its completion,
residual predicates and exact agreement with the six predicted seed orbits.
"""

import json
import re
import sys
from itertools import combinations
from math import gcd
from pathlib import Path

SEEDS = {
    33: [(1, 4, 16, 22, 25, 31)],
    39: [(1, 7, 16, 22, 34, 37), (1, 14, 16, 22, 29, 35)],
    45: [(1, 19, 20, 28, 30, 37)],
    105: [(1, 22, 43, 64, 90, 95), (3, 24, 50, 66, 85, 87)],
}


def check(directory):
    degrees = [*range(3, 106, 2), 3465, 3675]
    assert (directory / "run-status.txt").read_text().strip() == "PASS"
    assert list(map(int, (directory / "completed-degrees.txt").read_text().split())) == degrees
    residuals = primitive = orbits = 0
    for m in degrees:
        units = [t for t in range(1, m) if gcd(t, m) == 1]

        def balanced(a):
            return all(2 * sum(t * x % m for x in a) == len(a) * m for t in units)

        def canonical(a):
            return min(tuple(sorted(t * x % m for x in a)) for t in units)

        def residual(a):
            if any((x + y) % m == 0 for x, y in combinations(a, 2)):
                return False
            if m % 5 == 0:
                for x in a:
                    if 5 * x % m and sorted(a) == sorted(
                        [(x + j * (m // 5)) % m for j in range(5)] + [-5 * x % m]
                    ):
                        return False
            for indices in combinations(range(1, 6), 2):
                chosen = (0, *indices)
                b = tuple(a[i] for i in chosen)
                c = tuple(a[i] for i in range(6) if i not in chosen)
                s = sum(b) % m
                if s and balanced((*b, -s % m)) and balanced((s, *c)):
                    return False
            return True

        raw = (directory / f"m{m}.txt").read_text()
        assert "VIOLATION" not in raw, m
        pair_triple = raw.startswith("BEGIN ")
        prefix = "DONE " if pair_triple else "SUMMARY "
        summaries = [line for line in raw.splitlines() if line.startswith(prefix)]
        assert len(summaries) == 1, m
        counts = {k: int(v) for k, v in re.findall(r"(\w+)=(\d+)", summaries[0])}
        assert counts["m"] == m, m
        if pair_triple:
            assert f"half_units={len(units) // 2} " in raw.splitlines()[0], m
            counts["orbit_classes"] = counts["nonpair_orbits"]
            counts["std5"] = counts["std5_only"]
            counts["residual_orbits"] = counts["residual"]
        else:
            assert counts["units"] == len(units), m
            assert counts["L718_viol"] == counts["L719_viol"] == 0, m
        found = set()
        for line in raw.splitlines():
            if pair_triple:
                if not line.startswith("ORBIT ") or not line.endswith(" residual=1"):
                    continue
                a = tuple(map(int, re.search(r"tuple=([\d,]+)", line).group(1).split(",")))
            else:
                if not line.startswith("RESIDUAL "):
                    continue
                a = tuple(map(int, line.split()[-6:]))
            g = gcd(m, *a)
            assert f"content={g} conductor={m // g} " in line, (m, line)
            assert all(0 < x < m for x in a) and balanced(a) and residual(a), (m, a)
            assert canonical(a) == a and a not in found, (m, a)
            found.add(a)
            primitive += g == 1
        predicted = {
            canonical(tuple((m // d) * x for x in a))
            for d, seeds in SEEDS.items() if m % d == 0 for a in seeds
        }
        assert found == predicted, (m, found - predicted, predicted - found)
        assert counts["residual_orbits"] == len(found), m
        assert counts["std5"] + counts["dec"] + len(found) == counts["orbit_classes"], m
        orbits += counts["orbit_classes"]
        residuals += len(found)
        print(json.dumps({"degree": m, "orbits": counts["orbit_classes"],
                          "residuals": len(found), "status": "PASS"}))
    print(json.dumps({"degrees": len(degrees), "orbits": orbits,
                      "residuals": residuals, "primitive_residuals": primitive,
                      "status": "PASS"}))


if __name__ == "__main__":
    check(Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).parent / "results/r4-20261030")
