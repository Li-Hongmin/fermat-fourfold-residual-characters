"""Exact-lower-stratum 'positive block' check (the E=0 branch of Lemma 7.19 / Thm 7.8 / 7.15):
for every N prime to 6 (5<=N<=Nmax), every odd integer v on U_N with ||v||_1=2r<=6 (no cancellation), put G=v(3.)-v,
B = {tops (s,u): s=+-1, v(u)>0}  U  {order-N entries from positive part of G}.  Build B as a sextuple/quad at m=3N,
test:  |B|=2r+d<=6; whether B is a Hodge multiset; pair-free; Dec; and tabulate (r,d,N)."""
import itertools, math, sys
from math import gcd
Nmax=int(sys.argv[1]) if len(sys.argv)>1 else 60
def hodge(m,ent):
    if sum(ent)%m: return False
    k=len(ent)
    for t in range(1,m):
        if gcd(t,m)!=1 or 2*t>m: continue
        if sum((t*x)%m for x in ent)!=m*k//2: return False
    return True
def is_dec(m,v):
    n=len(v)
    if n!=6: return None
    for B in itertools.combinations(range(6),3):
        if 0 not in B: continue
        C=[i for i in range(6) if i not in B]
        s=sum(v[i] for i in B)%m
        if s==0: continue
        if hodge(m,[v[i] for i in B]+[(-s)%m]) and hodge(m,[s]+[v[i] for i in C]): return True
    return False
summary={}
for N in range(5,Nmax+1,2):
    if gcd(N,6)!=1: continue
    m=3*N; U=[u for u in range(1,N) if gcd(u,N)==1]
    reps=[u for u in U if 2*u<N]
    for r in (1,2,3):
        seen=set()
        for combo in itertools.combinations_with_replacement(reps,r):
            for signs in itertools.product([1,-1],repeat=r):
                v={}
                for z,s in zip(combo,signs):
                    v[z]=v.get(z,0)+s
                if sum(abs(x) for x in v.values()) != r: continue
                # full odd function on U
                vf={u:0 for u in U}
                for z,x in v.items(): vf[z]+=x; vf[(-z)%N]-=x
                key=tuple(sorted(vf.items()))
                if key in seen: continue
                seen.add(key)
                # G(y)=v(3y)-v(y); positive part gives order-N entries 3y with multiplicity G(y)>0 (as element 3y of Z/3N)
                G={y:vf[(3*y)%N]-vf[y] for y in U}
                d=sum(abs(x) for x in G.values())//2
                if 2*r+d>6: continue
                ent=[]
                for u in U:
                    if vf[u]>0:
                        for s in (1,2):  # CRT elements (s mod 3, u mod N)
                            x=next(x for x in range(m) if x%3==s and x%N==u)
                            ent+= [x]*vf[u]
                for y in U:
                    if G[y]>0:
                        ent+=[(3*y)%m]*G[y]   # element of order N: 3y mod 3N has N-component 3y
                # NB element (0 mod 3, w mod N) = 3*(3^{-1}w) ; here y indexes G(y)=n_{3y}-n_{-3y}, entry value 3y mod 3N
                ok=hodge(m,ent) if len(ent)==2*r+d else False
                pf=all((a+b)%m for a,b in itertools.combinations(ent,2))
                dec=is_dec(m,ent) if len(ent)==6 else None
                assert ok and pf, (N, r, d, ent)
                if r == 1:
                    assert d == 2 and len(ent) == 4, (N, r, d)
                elif r == 2:
                    assert d == 2 and dec, (N, r, d, ent)
                    z = next(u for u in U if vf[u] > 0 and vf[3*u % N] > 0)
                    # Equation (7.14e): contract -3z and 3z in the
                    # two standard surfaces with parameters z and 3z.
                    witness = [x % m for x in
                               (z, z+N, z+2*N, 3*z+N, 3*z+2*N, -9*z)]
                    assert sorted(witness) == sorted(ent), (N, z, witness, ent)
                else:
                    assert N == 13 and d == 0 and not dec, (N, r, d, ent)
                summary.setdefault((r,d,len(ent)),[]).append((N,ok,pf,dec))
for k,v in sorted(summary.items()):
    Ns=sorted({x[0] for x in v})
    print(f"r={k[0]} d={k[1]} |B|={k[2]}: count={len(v)} N in {Ns[:12]}{'...' if len(Ns)>12 else ''}  allHodge={all(x[1] for x in v)} pairfree={sum(x[2] for x in v)}/{len(v)} Dec={sum(1 for x in v if x[3])}/{sum(1 for x in v if x[3] is not None)}")
