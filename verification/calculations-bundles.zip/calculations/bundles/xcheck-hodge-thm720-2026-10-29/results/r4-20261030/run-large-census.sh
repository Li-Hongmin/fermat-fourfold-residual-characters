#!/usr/bin/env bash
set -euo pipefail
cd /gs/bs/tga-satolab-gtex/lihongmin/hodge-r4-20261030
gcc -O3 -std=c11 residual_pair_triple_through3675.c -o pair-triple
sha256sum residual_pair_triple_through3675.c > results/large-source-sha256.txt
for m in 3465 3675; do
  /usr/bin/time -v nice -n 15 ./pair-triple "$m" > "results/m${m}.txt" 2> "results/m${m}.time.txt"
  printf '%s\n' "$m" >> results/completed-degrees.txt
done
printf '%s\n' PASS > results/run-status.txt
