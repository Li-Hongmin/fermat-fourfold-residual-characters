#!/usr/bin/env bash
set -euo pipefail
cd /gs/bs/tga-satolab-gtex/lihongmin/hodge-r4-20261030
mkdir -p results
{
  date -u
  hostname
  gcc --version | head -1
  python3 --version
  sha256sum hs_enum3.c
} > results/environment.txt
gcc -O3 -std=c11 hs_enum3.c -o hs_enum3
for m in $(seq 3 2 105) 3465 3675; do
  /usr/bin/time -v nice -n 15 ./hs_enum3 "$m" > "results/m${m}.txt" 2> "results/m${m}.time.txt"
  printf '%s\n' "$m" >> results/completed-degrees.txt
done
printf '%s\n' PASS > results/run-status.txt
