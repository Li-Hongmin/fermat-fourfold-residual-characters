/*
 * Independent cross-check for Theorem 7.20 (Residual characters of odd-degree Fermat fourfolds).
 * Written from the definitions in Sections 2.3 and 7 only; it reads no earlier checker/census.
 *
 * For one odd degree m it enumerates ALL pair-free Hodge sextuples (multisets of six nonzero residues
 * with sum 0 mod m and age_t = 3 for every unit t) by meet-in-the-middle on 3+3 splits, then classifies
 * each as  Std5 | Dec (3+3 surface split with sums s,-s != 0) | other(residual or curve-product only),
 * and also evaluates the structural claims used in Lemmas 7.18, 7.19.
 *
 * usage: hs_enum m [verbose]
 * output (one line per orbit class of pair-free sextuples that is NOT Dec and NOT Std5, and summary lines)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

static int m;
static int *units, nunits;      /* units mod m in 1..m-1            */
static int *isunit;
static int t1, t2, t3, t4;           /* three hashing units               */
static int *tab1, *tab2, *tab3, *tab4;  /* tab[x] = (t*x) mod m              */

static int gcd(int a, int b){ while(b){int t=a%b;a=b;b=t;} return a; }

typedef struct { uint64_t key; int a,b,c; } Tri;

static int cmp_tri(const void*x,const void*y){
    const Tri*p=x,*q=y; if(p->key<q->key) return -1; if(p->key>q->key) return 1; return 0;
}

static inline uint64_t mk4(int A1,int A2,int A3,int A4){
    return ((uint64_t)A1<<48) | ((uint64_t)A2<<32) | ((uint64_t)A3<<16) | (uint64_t)A4;
}

/* full Hodge check of a multiset of k entries: sum of ages == (k/2) for all units */
static int is_hodge(const int*v,int k){
    long s=0; for(int i=0;i<k;i++) s+=v[i];
    if(s%m) return 0;
    for(int u=0;u<nunits;u++){
        int t=units[u]; if(2*t>m) break;   /* t and -t symmetric */
        long a=0; for(int i=0;i<k;i++) a+=(long)t*v[i]%m;
        if(a!=(long)m*k/2) return 0;
    }
    return 1;
}

static int cmpint(const void*a,const void*b){return *(const int*)a-*(const int*)b;}

static int is_dec(const int*v){ /* v: six entries; 10 splits into 3+3 */
    for(int mask=0;mask<64;mask++){
        if(__builtin_popcount(mask)!=3) continue;
        if(!(mask&1)) continue;
        int B[4],C[4],nb=0,nc=0;
        for(int i=0;i<6;i++){ if(mask>>i&1) B[nb++]=v[i]; else C[nc++]=v[i]; }
        int s=(B[0]+B[1]+B[2])%m; if(s==0) continue;
        int Q1[4]={B[0],B[1],B[2],(m-s)%m};
        int Q2[4]={s,C[0],C[1],C[2]};
        if(is_hodge(Q1,4)&&is_hodge(Q2,4)) return 1;
    }
    return 0;
}

static int is_std5(const int*v){
    if(m%5) return 0;
    int d=m/5;
    for(int i0=0;i0<6;i0++){
        int x=v[i0];
        if((5L*x)%m==0) continue;
        int w[6]; for(int j=0;j<5;j++) w[j]=(x+j*d)%m; w[5]=(int)(((long)m-(5L*x)%m)%m);
        int a[6],b[6]; memcpy(a,v,sizeof a); memcpy(b,w,sizeof b);
        qsort(a,6,sizeof(int),cmpint); qsort(b,6,sizeof(int),cmpint);
        if(!memcmp(a,b,sizeof a)) return 1;
    }
    return 0;
}

static int has_pair(const int*v,int k){
    for(int i=0;i<k;i++)for(int j=i+1;j<k;j++) if((v[i]+v[j])%m==0) return 1;
    return 0;
}

static void canon(const int*v,int*out){
    int best[6]; int first=1;
    for(int u=0;u<nunits;u++){
        int t=units[u]; int w[6];
        for(int i=0;i<6;i++) w[i]=(int)((long)t*v[i]%m);
        qsort(w,6,sizeof(int),cmpint);
        int c=-1;
        if(!first){ c=0; for(int i=0;i<6;i++){ if(w[i]!=best[i]){ c=w[i]<best[i]?-1:1; break; } } }
        if(first||c<0){ memcpy(best,w,sizeof w); first=0; }
    }
    memcpy(out,best,sizeof best);
}

/* ---------- bookkeeping of distinct orbit classes ---------- */
typedef struct { int v[6]; int dec, std5; } Orb;
static Orb *orbs; static int norb, cap;

static int find_or_add(const int*c){
    for(int i=0;i<norb;i++) if(!memcmp(orbs[i].v,c,6*sizeof(int))) return i;
    if(norb==cap){cap=cap?cap*2:64; orbs=realloc(orbs,cap*sizeof(Orb));}
    memcpy(orbs[norb].v,c,6*sizeof(int)); orbs[norb].dec=-1; orbs[norb].std5=-1; return norb++;
}

/* order of x in Z/m */
static int ord_of(int x){ return m/gcd(m,x); }

/* count points of an arithmetic progression P_x={x+j m/5} in multiset */
static int pts_in_P5(const int*v,int x){
    int d=m/5,cnt=0;
    for(int j=0;j<5;j++){ int y=(x+j*d)%m; for(int i=0;i<6;i++) if(v[i]==y){cnt++;break;} }
    return cnt;
}

static long c718,v718,c719,v719;
static void stress(const int*v,int g,int st,int dc){
    if(g==1 && !st && m%5==0){
        for(int i=0;i<6;i++){
            int x=v[i]; if((5L*x)%m==0) continue;
            int c=pts_in_P5(v,x);
            if(c==4){
                int ok=(45%m==0)||(105%m==0);
                c718++; if(!ok){ v718++; printf("L718-VIOLATION m=%d type=%s %d %d %d %d %d %d\n",m,dc?"Dec":"RES",v[0],v[1],v[2],v[3],v[4],v[5]); }
                break;
            }
        }
    }
    if(g==1 && m%3==0 && (m/3)%3!=0){
        int ords[6]; for(int i=0;i<6;i++) ords[i]=ord_of(v[i]);
        int maxo[6],nmax=0,allthree=1;
        for(int i=0;i<6;i++){
            int ismax=1; for(int j=0;j<6;j++) if(ords[j]!=ords[i]&&ords[j]%ords[i]==0){ismax=0;break;}
            if(ismax){ int dup=0; for(int k=0;k<nmax;k++) if(maxo[k]==ords[i]) dup=1; if(!dup) maxo[nmax++]=ords[i]; }
        }
        for(int k=0;k<nmax;k++) if(maxo[k]%3) allthree=0;
        if(!allthree) return;
        for(int k=0;k<nmax;k++){
            int e=maxo[k], N=e/3; if(N==1) continue;
            int *Dacc=calloc(N,sizeof(int));
            for(int i=0;i<6;i++) if(ords[i]==e){
                int z=v[i]/(m/e); int sgn=(z%3==1)?1:-1; int u=z%N, mu=(N-u)%N;
                Dacc[u]+=sgn; Dacc[mu]+=sgn;
            }
            int Dzero=1; for(int u=0;u<N;u++) if(Dacc[u]){Dzero=0;break;}
            free(Dacc);
            if(Dzero){
                c719++;
                int is39=(m==39);
                if(!(dc||is39)){ v719++; printf("L719-VIOLATION m=%d e=%d %d %d %d %d %d %d\n",m,e,v[0],v[1],v[2],v[3],v[4],v[5]); }
            }
        }
    }
}

#define MAXNT 32
static int NT, ts[MAXNT]; static int *tabj;   /* tabj[j*m+x] = ts[j]*x mod m */
int main(int argc,char**argv){
    m=atoi(argv[1]);
    isunit=calloc(m,sizeof(int)); units=malloc(m*sizeof(int)); nunits=0;
    for(int x=1;x<m;x++) if(gcd(x,m)==1){ isunit[x]=1; units[nunits++]=x; }
    /* hashing units: up to MAXNT of the half-units, evenly spread.  For a bucket with fixed sum s, A_t = (t s mod m) + m*k_t, k_t in {0,1,2}:
       the key is the base-3 string of the k_t (this is what makes the meet-in-the-middle key informative). */
    int nh=0; int *half=malloc(sizeof(int)*nunits); for(int u=0;u<nunits;u++) if(2*units[u]<m) half[nh++]=units[u];
    NT = nh<MAXNT? nh: MAXNT; for(int j=0;j<NT;j++) ts[j]=half[(long)j*nh/NT];
    tabj=malloc(sizeof(int)*(long)NT*m); for(int j=0;j<NT;j++) for(int x=0;x<m;x++) tabj[(long)j*m+x]=(int)((long)ts[j]*x%m);
    int divs[256],nd=0; for(int g=1;g<m;g++) if(m%g==0) divs[nd++]=g;
    long cap2=(long)m*m/6+m;
    Tri*L2=malloc(sizeof(Tri)*cap2);
    long nfound=0,nstd=0,ndec=0,nother=0,ncand=0;
    for(int s=0;s<m;s++){
        int s2=(m-s)%m; long n2=0;
        int base2[MAXNT]; for(int j=0;j<NT;j++) base2[j]=(int)((long)ts[j]*s2%m);
        for(int a=1;a<m;a++) for(int b=a;b<m;b++){
            int c=s2-a-b; c%=m; if(c<0) c+=m; if(c<b||c==0) continue;
            uint64_t key=0; int bad=0;
            for(int j=0;j<NT;j++){ int A=tabj[(long)j*m+a]+tabj[(long)j*m+b]+tabj[(long)j*m+c]; int k=(A-base2[j])/m; key=key*3+k; }
            L2[n2].key=key; L2[n2].a=a;L2[n2].b=b;L2[n2].c=c; n2++; (void)bad;
        }
        qsort(L2,n2,sizeof(Tri),cmp_tri);
        for(int di=0;di<nd;di++){
            int g=divs[di];
            for(int x=1;x<m;x++){
                int y=((s-g-x)%m+2*m)%m; if(y<x||y==0) continue;
                if((g+x)%m==0||(g+y)%m==0||(x+y)%m==0) continue;
                uint64_t key=0; int ok=1;
                for(int j=0;j<NT;j++){ int A1=tabj[(long)j*m+g]+tabj[(long)j*m+x]+tabj[(long)j*m+y]; int need=3*m-A1-base2[j];
                    if(need<0||need%m){ ok=0; break; } int k=need/m; if(k>2){ok=0;break;} key=key*3+k; }
                if(!ok) continue;
                long lo=0,hi=n2; while(lo<hi){ long mid=(lo+hi)/2; if(L2[mid].key<key) lo=mid+1; else hi=mid; }
                for(long q=lo;q<n2&&L2[q].key==key;q++){
                    int v[6]={g,x,y,L2[q].a,L2[q].b,L2[q].c}; ncand++;
                    if(has_pair(v,6)) continue;
                    if(!is_hodge(v,6)) continue;
                    nfound++;
                    int cv[6]; canon(v,cv);
                    int before=norb; int id=find_or_add(cv); if(id==before){
                        int *w=orbs[id].v; qsort(w,6,sizeof(int),cmpint);
                        orbs[id].std5=is_std5(w); orbs[id].dec=orbs[id].std5?0:is_dec(w);
                    }
                }
            }
        }
    }
    for(int o=0;o<norb;o++){
        int*v=orbs[o].v; int g=m; for(int i=0;i<6;i++) g=gcd(g,v[i]);
        int st=orbs[o].std5, dc=orbs[o].dec;
        if(argc>2) printf("ORBIT m=%d category=%s %d %d %d %d %d %d\n",
                         m,st?"std5":dc?"dec":"residual",v[0],v[1],v[2],v[3],v[4],v[5]);
        if(st) nstd++; else if(dc) ndec++; else { nother++; printf("RESIDUAL m=%d content=%d conductor=%d  %d %d %d %d %d %d\n",m,g,m/g,v[0],v[1],v[2],v[3],v[4],v[5]); }
        stress(v,g,st,dc);
    }
    printf("SUMMARY m=%d units=%d raw_reps=%ld orbit_classes=%d std5=%ld dec=%ld residual_orbits=%ld L718_tested=%ld L718_viol=%ld L719_tested=%ld L719_viol=%ld cand=%ld\n",m,nunits,nfound,norb,nstd,ndec,nother,c718,v718,c719,v719,ncand);
    return 0;
}
