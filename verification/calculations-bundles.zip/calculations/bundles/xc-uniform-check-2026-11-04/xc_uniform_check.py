#!/usr/bin/env python3
"""Independent check of the enumeration-free base closure (xc, 2026-11-04).

Written from scratch; shares no code with reviews/agy-hodge-uniform-2026-11-04/.
Run:  python3 -I xc_uniform_check.py  > xc_uniform_check.out.json

Checks
 E  exhaustive meet-in-the-middle census of pair-free Hodge sextuples at the
    eight degrees S = {3,5,15,21,33,39,45,105}; Std5 / Dec / residual orbits.
 P  potential solutions (Lemma 7.1 form) of length six at 3q, q in {5,7,11,13},
    compared with the closed-form list used in the patch.
 F  four points of a five-progression at 45 and 105: all solutions.
 B  the three degree-105 branches of Theorem 7.20 (K7 line pair with R=5,
    exceptional 8/4 matrix at N=35, coexisting maximal orders 15 and 21).
 Q  surface-quadruple facts: unit count at 33, 39; the 15-torsion property
    at 45, 105 used in the pigeonhole non-decomposability argument.
"""
import itertools, json, math, sys
from collections import defaultdict

def units(m): return [t for t in range(1, m) if math.gcd(t, m) == 1]

def balanced(m, T):
    s = 3 * m if len(T) == 6 else 2 * m
    return all(sum((t * a) % m for a in T) == s for t in units(m)) and all(a % m for a in T)

def pair_free(m, T):
    S = list(T)
    return not any((S[i] + S[j]) % m == 0 for i in range(len(S)) for j in range(i + 1, len(S)))

def canon(m, T):
    return min(tuple(sorted((t * a) % m for a in T)) for t in units(m))

def is_std5(m, T):
    if m % 5: return False
    d = m // 5
    for i in range(1, m):
        if (5 * i) % m == 0: continue
        if sorted(T) == sorted([(i + k * d) % m for k in range(5)] + [(-5 * i) % m]):
            return True
    return False

def is_dec(m, T):
    if not pair_free(m, T): return True
    T = list(T)
    for B in itertools.combinations(range(6), 3):
        if 0 not in B: continue
        Bv = [T[i] for i in B]; Cv = [T[i] for i in range(6) if i not in B]
        s = sum(Bv) % m
        if s == 0: continue
        if balanced(m, Bv + [(-s) % m]) and balanced(m, Cv + [s]):
            return True
    return False

def census(m):
    U = units(m)
    vec = {a: tuple((t * a) % m for t in U) for a in range(1, m)}
    trip = defaultdict(list)
    for tr in itertools.combinations_with_replacement(range(1, m), 3):
        v = tuple(map(sum, zip(*(vec[a] for a in tr))))
        trip[v].append(tr)
    out = set()
    target = 3 * m
    for v, lst in trip.items():
        w = tuple(target - x for x in v)
        if w not in trip: continue
        for t1 in lst:
            for t2 in trip[w]:
                T = tuple(sorted(t1 + t2))
                if pair_free(m, T): out.add(canon(m, T))
    res = {"std5": [], "dec": [], "residual": []}
    for T in sorted(out):
        assert balanced(m, T)
        res["std5" if is_std5(m, T) else "dec" if is_dec(m, T) else "residual"].append(T)
    return res

SEEDS = {33: [(1, 4, 16, 22, 25, 31)], 39: [(1, 7, 16, 22, 34, 37), (1, 14, 16, 22, 29, 35)],
         45: [(1, 19, 20, 28, 30, 37)], 105: [(1, 22, 43, 64, 90, 95), (3, 24, 50, 66, 85, 87)]}

def crt(a3, bq, q):
    m = 3 * q
    return next(x for x in range(m) if x % 3 == a3 % 3 and x % q == bq % q)

def potentials(q):
    """All pair-free length-6 functions F = u(a)+v(b) on U_3 x U_q with strata (7.3)."""
    m = 3 * q; Uq = units(q); reps = [b for b in Uq if b < q - b]
    sols = set()
    for lam in (0, 1):
        vals = [x / 2 for x in range(-6, 7) if (x % 2 == lam)]
        def gen(k, budget):
            if k == 0:
                yield (); return
            for x in vals:
                if abs(x) <= budget:
                    for rest in gen(k - 1, budget - abs(x)): yield (x,) + rest
        for mu in vals:
            for vv in gen(len(reps), 3):
                v = {}
                for b, x in zip(reps, vv): v[b] = x; v[q - b] = -x
                u = {1: mu, 2: -mu}
                F = defaultdict(float)
                for a in (1, 2):
                    for b in Uq: F[crt(a, b, q)] += u[a] + v[b]
                for y in (1, 2):  # order-3 stratum q*y
                    F[(q * y) % m] += u[(q * y) % 3] - u[y]
                for z in Uq:      # order-q stratum 3*z
                    F[(3 * z) % m] += v[(3 * z) % q] - v[z]
                if sum(abs(x) for x in F.values()) / 2 != 6: continue
                if any(abs(x - round(x)) > 1e-9 for x in F.values()): continue
                T = []
                for x, c in F.items():
                    if c > 0: T += [x] * int(round(c))
                T = tuple(sorted(T))
                if len(T) == 6 and pair_free(m, T):
                    assert balanced(m, T), (q, T)
                    sols.add((lam, canon(m, T)))
    return sorted(sols)

def four_points(m):
    d = m // 5; out = set()
    for x in range(1, m):
        if (5 * x) % m == 0: continue
        P = [(x + k * d) % m for k in range(5)]
        for z in P:
            base = [p for p in P if p != z]
            for b, c in itertools.combinations_with_replacement(range(1, m), 2):
                T = tuple(sorted(base + [b, c]))
                if math.gcd(math.gcd(*T), m) != 1: continue
                if not pair_free(m, T) or is_std5(m, T): continue
                if balanced(m, T): out.add(canon(m, T))
    return sorted(out)

def branches105():
    m = 105; r = {}
    # (A) K7-line pair, R=5: tops (sigma, eps_k * w * k), k in K7 = ker(U35->U5)
    U35 = units(35); K7 = [k for k in U35 if k % 5 == 1]
    hitsA = 0
    for sig in (1, 2):
        for w in U35:
            for eps in itertools.product((1, -1), repeat=6):
                T = [next(x for x in range(m) if x % 3 == sig and x % 35 == (e * w * k) % 35) for e, k in zip(eps, K7)]
                if balanced(m, T): hitsA += 1
    r["A_K7_line_pair_R5_balanced_configs"] = hitsA
    # (C) no balanced sextuple (pairs allowed) whose entries all have order dividing 15 or 21,
    #     with both 15 and 21 occurring as orders
    elems = [a for a in range(1, m) if (15 * a) % m == 0 or (21 * a) % m == 0]
    hitsC = 0
    for T in itertools.combinations_with_replacement(elems, 6):
        if sum(T) % m: continue
        ords = {m // math.gcd(a, m) for a in T}
        if 15 in ords and 21 in ords and balanced(m, T) and pair_free(m, T): hitsC += 1
    r["C_coexisting_15_21_pairfree_balanced"] = hitsC
    return r

def surface_quadruples(m):
    out = []
    for Q in itertools.combinations_with_replacement(range(1, m), 4):
        if sum(Q) % m == 0 and pair_free(m, Q) and balanced(m, Q): out.append(Q)
    return out

def main():
    rep = {}
    S = [3, 5, 15, 21, 33, 39, 45, 105]
    tot = {"std5": 0, "dec": 0, "residual": 0}
    for m in S:
        c = census(m)
        for k in tot: tot[k] += len(c[k])
        rep[f"E_{m}"] = {k: [list(t) for t in v] for k, v in c.items()}
        assert sorted(canon(m, s) for s in SEEDS.get(m, [])) == c["residual"], m
    rep["E_totals"] = tot
    rep["P"] = {q: potentials(q) for q in (5, 7, 11, 13)}
    rep["F_45"] = four_points(45); rep["F_105"] = four_points(105)
    rep["B_105"] = branches105()
    Qs = {}
    for m in (33, 39):
        qs = surface_quadruples(m)
        Qs[f"units_per_quadruple_{m}"] = sorted({sum(math.gcd(a, m) == 1 for a in Q) for Q in qs})
    for m in (45, 105):
        bad = 0; qs = surface_quadruples(m)
        for Q in qs:
            for a, b in itertools.combinations(Q, 2):
                if (m // math.gcd((a - b) % m, m)) == 5 and any((15 * e) % m for e in Q): bad += 1
        Qs[f"order5_difference_without_15torsion_{m}"] = bad
        Qs[f"pairfree_surface_quadruples_{m}"] = len(qs)
    rep["Q"] = Qs
    # explicit decompositions used in the patch at degree 21
    rep["Dec21"] = {"(1,4,10,13,16,19)": is_dec(21, (1, 4, 10, 13, 16, 19)),
                    "(1,4,9,15,16,18)": is_dec(21, (1, 4, 9, 15, 16, 18)),
                    "Q1=(1,10,15,16) bal": balanced(21, (1, 10, 15, 16)),
                    "Q2=(4,9,11,18) bal": balanced(21, (4, 9, 11, 18))}
    json.dump(rep, sys.stdout, indent=1, default=list)

if __name__ == "__main__":
    main()
