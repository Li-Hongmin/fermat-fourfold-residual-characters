#!/bin/bash
#$ -cwd
#$ -l cpu_4=1
#$ -l h_rt=0:30:00
#$ -N hodgeR10base
#$ -j y
#$ -o /gs/bs/tga-satolab-gtex/lihongmin/hodge-r10-minbase-20261104/logs/
# R10 naive exhaustive check at the eight base degrees of Prop 7.21. Batch only.
R=/gs/bs/tga-satolab-gtex/lihongmin/hodge-r10-minbase-20261104
cd $R; mkdir -p results logs bin
echo "JOB $JOB_ID host $(hostname) start $(date -Is)"; cc --version | head -1; python3 --version
cc -O2 -o bin/naive6 naive6.c || exit 2
for m in 3 5 15 21 33 39 45 105; do
  /usr/bin/time -v bin/naive6 $m > results/rows_$m.txt 2> results/summary_$m.txt; echo "m=$m enum rc=$?"
  python3 -I classify_r9.py $m results/rows_$m.txt > results/class_$m.json; echo "m=$m classify rc=$?"
  cut -c1-300 results/class_$m.json
done
echo "end $(date -Is)"
