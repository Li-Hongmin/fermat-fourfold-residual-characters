"""Classify mitm6 output (R9). Independent of classify.py / cl.py code paths
except for the definitions fixed in the manuscript (Dec: some 3+3 split with
distinguished sum s!=0 making (B,-s),(C,s) age 2 at every unit; Std5).
usage: classify_r9.py m rows.txt -> JSON line on stdout"""
import sys, math, json, itertools
m=int(sys.argv[1]); U=[t for t in range(1,m) if math.gcd(t,m)==1]
def age(tup):
    return {sum((t*x)%m for x in tup) for t in U}
def canon(tup): return min(tuple(sorted((t*x)%m for x in tup)) for t in U)
rows={tuple(sorted(map(int,l.split()))) for l in open(sys.argv[2]) if l.strip()}
for r in rows:  # re-verify independently of the C code
    assert age(r)=={3*m} and all(x%m for x in r)
    assert all((r[i]+r[j])%m for i in range(6) for j in range(i+1,6))
orbits=sorted({canon(r) for r in rows})
def dec(T):
    for B in itertools.combinations(range(6),3):
        b=[T[i] for i in B]; c=[T[i] for i in range(6) if i not in B]; s=sum(b)%m
        if s and age(b+[(-s)%m])=={2*m} and age(c+[s])=={2*m}: return True
    return False
def std5(T):
    if m%5: return False
    d=m//5
    return any(sorted(T)==sorted([(i+k*d)%m for k in range(5)]+[(-5*i)%m]) for i in range(m) if i%d)
SEEDS={33:[(1,4,16,22,25,31)],39:[(1,7,16,22,34,37),(1,14,16,22,29,35)],45:[(1,19,20,28,30,37)],
       105:[(1,22,43,64,90,95),(3,24,50,66,85,87)]}
pred=set()
for N,ss in SEEDS.items():
    if m%N==0:
        for s in ss: pred.add(canon([x*(m//N) for x in s]))
cat={}
for o in orbits: cat[o]='std5' if std5(o) else ('dec' if dec(o) else 'residual')
res=sorted(o for o in orbits if cat[o]=='residual')
formula=(m%33==0)+2*(m%39==0)+(m%45==0)+2*(m%105==0)
out=dict(m=m,distinct_rows=len(rows),orbits=len(orbits),std5=sum(v=='std5' for v in cat.values()),
         dec=sum(v=='dec' for v in cat.values()),residual=len(res),formula=formula,
         residual_equals_seed_inflations=(set(res)==pred),residuals=res)
print(json.dumps(out))
sys.exit(0 if out['residual_equals_seed_inflations'] and len(res)==formula else 1)
