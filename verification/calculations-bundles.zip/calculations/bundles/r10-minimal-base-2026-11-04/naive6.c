/* r10 naive exhaustive enumerator: every sorted 6-multiset of nonzero
   residues mod m with sum 3m, pair-free, age 3m at every unit.
   No orbit normalization, no conductor bound, no hashing. */
#include <stdio.h>
#include <stdlib.h>
static int g(int a,int b){while(b){int t=a%b;a=b;b=t;}return a;}
int main(int c,char**v){int m=atoi(v[1]);int U[4096],nu=0;
 for(int t=1;t<m;t++) if(g(t,m)==1) U[nu++]=t;
 long n=0; int a[6];
 for(a[0]=1;a[0]<m;a[0]++)for(a[1]=a[0];a[1]<m;a[1]++)for(a[2]=a[1];a[2]<m;a[2]++)
 for(a[3]=a[2];a[3]<m;a[3]++){int r=3*m-a[0]-a[1]-a[2]-a[3]; if(r<2*a[3]) break;
  for(a[4]=a[3];a[4]<m;a[4]++){a[5]=r-a[4]; if(a[5]<a[4]) break; if(a[5]>=m) continue;
   int ok=1; for(int i=0;i<6&&ok;i++)for(int j=i+1;j<6;j++) if((a[i]+a[j])%m==0){ok=0;break;}
   for(int k=0;k<nu&&ok;k++){int s=0;for(int i=0;i<6;i++) s+=(U[k]*a[i])%m; if(s!=3*m) ok=0;}
   if(ok){n++;printf("%d %d %d %d %d %d\n",a[0],a[1],a[2],a[3],a[4],a[5]);}}}
 fprintf(stderr,"m=%d rows=%ld\n",m,n);return 0;}
