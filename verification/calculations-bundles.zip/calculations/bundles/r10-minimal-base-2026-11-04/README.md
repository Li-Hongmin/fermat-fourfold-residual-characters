# r10 minimal-base check (2026-11-04)

Purpose: independent exhaustive check of Proposition 4.1 at the eight degrees
S = {3,5,15,21,33,39,45,105}, the only degrees of the finite base that the proof of
Theorem A uses (manuscript Proposition 7.21).

- `naive6.c`: loops over every sorted 6-multiset of nonzero residues with sum 3m
  (fifth loop forces the sixth entry), rejects inverse pairs, checks the age at every
  unit. No orbit normalization, no gcd normalization, no hashing, no conductor bound.
  Output: every Hodge row (not orbit representatives).
- `classify_r9.py`: copy of the r9 classifier (re-verifies each row in Python, then
  Std5 -> Dec -> residual, compares with seed inflations).
- `tsubame_r10.sh`: TSUBAME 4.0 batch job 9251008 (qsub -g tga-satolab-gtex, cpu_4,
  h_rt 0:30, GCC 11.5, Python 3.9), node r15n2, 2026-11-04 02:55:31-02:55:32 JST.
  Local compilation was not possible (macOS linker error), so the run is batch only.
- `results/tsubame-9251008/`: raw rows, /usr/bin/time -v summaries, class JSON, job log,
  remote source copy (identical to `naive6.c`).

Result: orbit counts (total/Std5/Dec/residual) 3:0/0/0/0, 5:0/0/0/0, 15:2/1/1/0,
21:3/0/3/0, 33:2/0/1/1, 39:3/0/1/2, 45:8/2/5/1, 105:10/3/5/2; 28 orbits in all.
Canonical orbit sets equal those of r9 `mitm6` (results/local-smoke) at all eight
degrees, and the residuals are exactly the six seeds of (3.1).
